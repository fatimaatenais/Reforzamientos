mi_nombre = "Fátima Trujillano Rojas"
mi_saludo = "¡HI " + mi_nombre + "!"

print(mi_saludo)
