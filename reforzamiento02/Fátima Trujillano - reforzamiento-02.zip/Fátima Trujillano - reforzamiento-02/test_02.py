mi_edad = 17
mi_resultado01 = mi_edad * 10
mi_resultado02 = mi_edad - 10

conversion_float = float(mi_resultado01)
conversion02_float = float(mi_resultado02)

print(type(conversion_float))
print(type(conversion02_float))
