dni = "78654698"
edad = 17

mi_suma = edad + int(dni)

print(mi_suma)

