objeto = "pelota"
volumen_de_la_pelota = 696.91
la_constante = 4/3
valor_de_pi = 3.14
radio_de_la_pelota = 5.5

print("Datos de tu {}".format(objeto))
print("Volumen: {}".format(volumen_de_la_pelota))
print("Radio: {}".format(radio_de_la_pelota))

