monto = 2500

if monto % 2 == 0:
    print("Tu monto de {} ES PAR!".format(monto))

#Aquí añadí igual else...

else:
    print("Tu monto de {} ES IMPAR!".format(monto))


