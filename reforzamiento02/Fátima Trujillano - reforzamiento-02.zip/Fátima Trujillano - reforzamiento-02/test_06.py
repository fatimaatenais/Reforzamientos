# Medidas de objetos:

cartuchera = 12.5
lapicero = 5.7
celular = 14.50
mesa = 80.50
cuaderno = 28.45

media_de_los_objetos = cartuchera + lapicero + celular + mesa + cuaderno / 5
print("La media es {}".format(media_de_los_objetos))
print(type(media_de_los_objetos))
