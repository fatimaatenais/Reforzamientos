# Variables

velocidad_01 = 60
velocidad_02 = -70
velocidad_03 = 85

suma = velocidad_01 % 3 + velocidad_02 % 5 + velocidad_03 % 7

print("Suma de los modulos:", suma)

