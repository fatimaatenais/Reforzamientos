frutas = []
verduras = ["tomate", "lechuga"]

if not frutas:
    print("Tu lista de frutas esta vacía")
else:
    print("Tu lista de frutas tiene datos")

if not verduras:
    print("Tu lista de verduras esta vacía")
else:
    print("Tu lista de verduras tiene datos")