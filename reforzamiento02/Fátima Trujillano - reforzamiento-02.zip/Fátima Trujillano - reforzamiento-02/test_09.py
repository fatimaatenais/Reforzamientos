caesar = 19
num_de_lista = 6

dato = pow(caesar, num_de_lista) - (caesar * 2)

print("Mi resultado= {}".format(dato))