numero = 2.718282

print("Variable con un decimal: {}".format(f"{numero:.1f}"))
print("Variable con dos decimales: {}".format(f"{numero:.2f}"))
print("Variable con cuatro decimales: {}".format(f"{numero:.4f}"))