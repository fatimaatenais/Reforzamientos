mi_edad = 17
resultado = pow(mi_edad, 5) / 10

print("Con modulo:", resultado % 3)
print("Tipo de dato:", type(resultado))
