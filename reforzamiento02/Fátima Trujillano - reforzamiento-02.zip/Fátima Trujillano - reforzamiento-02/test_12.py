cliente = "Fátima"
producto = "Lip balm Dior"
precio = 185.60
cantidad = 2

print("Buen día {}, el detalle de su compra es el siguiente:".format(cliente))
print("- Producto: {}".format(producto))
print("- Precio unitario: {}".format(precio))
print("- Cantidad: {}".format(cantidad))
print("- Total a pagar:", precio * 2)
