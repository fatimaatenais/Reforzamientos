temp_en_celsius_01 = 20
temp_en_fahrenheit_01 = (temp_en_celsius_01 * 9) / 5 + 32

print("La temperatura 1 en °C: {}".format(temp_en_celsius_01))
print("Temperatura 1 en Fahrenheit: {}".format(temp_en_fahrenheit_01))

temp_en_celsius_02 = 10
temp_en_fahrenheit_02 = (temp_en_celsius_02 * 9) / 5 + 32

print("La temperatura 2 en °C: {}".format(temp_en_celsius_02))
print("Temperatura 2 en Fahrenheit: {}".format(temp_en_fahrenheit_02))